//
//  ViewController.swift
//  Cricketscoreboard
//
//  Created by MACOS on 6/23/17.
//  Copyright © 2017 MACOS. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {

    var temp1 = [String]()
    var res = [String]()
    var te = [Any]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let str = String("https://query.yahooapis.com/v1/public/yql?q=select%20*%20from%20cricket.scorecard%20where%20match_id%3D11985&format=json&diagnostics=true&env=store%3A%2F%2F0TxIGQMQbObzvU4Apia0V0&callback=")
      
        let url = URL(string: str!)
        
        do
        {
            let dt = try Data(contentsOf: url!)
            
            do
            {
                let dic = try JSONSerialization.jsonObject(with: dt, options: []) as! [String:Any]
                
                let query = dic["query"] as! [String:Any]
                
                let result = query["results"] as! [String:Any]

                let scoreboard = result["Scorecard"] as! [String:Any]
                
                let series = scoreboard["series"] as! [String:Any]
                
                temp1.append(series["series_id"] as! String)
                temp1.append(series["series_name"] as! String)
                
                let place = scoreboard["place"] as! [String:Any]
                
                temp1.append(place["stadium"] as! String)
                temp1.append(place["city"] as! String)
                temp1.append(place["country"] as! String)
                
                temp1.append(scoreboard["mn"] as! String)
             //   print(temp1)
                
                let team = scoreboard["teams"] as! [[String:Any]]
           
                for item in team
                {
                    var temp2 = [String]()
                    temp2.append(item["fn"] as! String)
                    
                    var ab = item["logo"] as! [String:Any]
                    
                    temp2.append(ab["std"] as! String)
                    print(temp2)
                    te.append(temp2)
                }
                
                let rest = scoreboard["result"]as! [String : Any]
                res.append(rest["winner"] as! String)
                res.append(rest["r"] as! String)
            
            }
            catch
            {
                
            }
        }
        catch
        {
            
        }
    
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        if section == 0
        {
            return "Seriesdetail"
        }
        else if section == 1
        {
            return "Teamdetail"
        }
        else
        {
            return "Results"
        }
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 3
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0
        {
            return temp1.count
        }
        else if section == 1
        {
            return te.count
        }
        else
        {
            return res.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if indexPath.section == 0
        {
           let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        
           cell?.textLabel?.text = temp1[indexPath.row]
        
          return cell!
        }
        else if indexPath.section == 1
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell1") as! custcell
            
            let dic = te[indexPath.row] as! [String]
            cell.lblteam1.text = dic[0]
           
           // let dicfinal = te[indexPath.row] as! [String]
            let imgurl = dic[1]
            let url = URL(string: imgurl)
            
            do
            {
                let data = try Data(contentsOf: url!)
                
                cell.imgview1.image = UIImage(data: data)
            }
            catch
            {
                
            }
            
            

           
            
            
            
           // cell.lblteam2.text = temp2[0]
            
            return cell
            
        }
        else
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell2")
            
            cell?.textLabel?.text = res[indexPath.row]
            return cell!

        }
    }


}

